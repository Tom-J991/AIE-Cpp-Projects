

#include "Application.h"

int main(int argc, char* argv[])
{
    {
        Application app;
        app.Run();
    }

    return 0;
}